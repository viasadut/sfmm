<?php
//require('force_justify.php');
//require('fpdf/fpdf.php');


require('force_justify.php');
$pmrn=$_REQUEST['pmrn'];
$id=$_REQUEST['id'];
//$date=$_REQUEST['date'];
$eid=$_REQUEST['eid'];

$db = mysqli_connect('localhost','root','Godiloveu16');
mysqli_select_db($db,'sfmmkpjnew');
$query = mysqli_query($db,"select * from einves where id='$id'");
$data = mysqli_fetch_array($query);

//$dname=$data['dname'];
//$query2 = mysqli_query($db,"select * from doctor1 where dname='$dname'");
//$data2 = mysqli_fetch_array($query2);




//$db = new PDO('mysql:host=localhost;dbname=sfmmkpj','root','');
class myPDF extends FPDF{
function header(){

$this->ln(35);

}

function footer(){
$this->SetY(-15);
$this->SetFont('Arial','B',8);

$this->ln(5);
$this->SetFont('Arial','B',10);
$this->Cell(0,10,'Contact Numbers:  Ambulance:  +880244077029, +8801791987466, Appointments: +880244077030, +8801703788561',0,0,'C');


}


//$this->Ln();
}


$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('P','A4',1);
$pdf->SetFont('Arial' , 'b' , 9);
$pdf->SetLeftMargin('15');
//$pdf->headerTable();
//$pdf->viewTable($db);


$pdf->SetFont('Arial' , 'b' , 15);
$pdf->Cell('182',6,$data['infusion'].' REPORT',1,1,'C');
//$this->SetFont('Arial','B',);

$pdf->ln(10);
$pdf->SetFont('Arial' , 'b' , 12);
$pdf->Cell('40',5,'Consultant Name:',0,0,'L');
$pdf->Cell('90',5,'DR. ABC',0,0,'L');
$pdf->ln(4);
$pdf->SetFont('Arial' , 'b' , 12);
$pdf->Cell('40');
//$pdf->Cell('160',5,$data2['degree'],0,0,'L');
$pdf->ln(4);
$pdf->SetFont('Arial' , 'b' , 12);
$pdf->Cell('40');
//$pdf->Cell('160',5,$data2['Discipline'],0,0,'L');

$pdf->ln(10);

$pdf->SetFont('Arial' , 'b' , 10);
$pdf->Cell('25',5,'Patient Name:',1,0,'L');
$pdf->Cell('60',5,$data['pname'],1,0,'L');
$pdf->Cell('15',5,'MRN:',1,0,'L');
$pdf->Cell('18',5,$data['pmrn'],1,0,'L');
$pdf->Cell('20',5,'GENDER:',1,0,'L');
$pdf->Cell('20',5,$data['pgender'],1,0,'L');
$pdf->Cell('10',5,'AGE:',1,0,'L');
$pdf->Cell('13',5,$data['page'],1,1,'L');

$pdf->ln(3);

//$pdf->SetFont('Arial' , 'b' , 10);
//$pdf->Cell('40',5,'Referral From:',1,0,'L');
//$pdf->Cell('141', 5,$data['dreffer'],1,1,'L');

$pdf->ln(3);

$pdf->SetFont('Arial' , 'b' , 10);


//$pdf->MultiCell('182' , 5,$data['report'],0,1);
//$pdf->ln(2);
$pdf->SetFont('Arial' , 'b' , 10);
//$pdf->MultiCell('95' , 10,$data['result'],1,"L",false);
//$pdf->MultiCell('95' , 10,$data['unit'],1,"L",false);
//$pdf->MultiCell('62' , 5,$data['reference'],0,"L",false);

$pdf->ln(3);

$pdf->SetFont('Arial' , 'b' , 10);
$pdf->Cell('100',5,'Result',1,0,'L');
$pdf->Cell('20',5,'Unit',1,0,'L');
$pdf->Cell('70',5,'Reference Value',1,1,'L');


$pdf->Cell('100',5,$data['result'],1,0,'L');
$pdf->Cell('20',5,'',1,0,'L');
$pdf->Cell('70',5,'',1,1,'L');


$pdf->ln(120);

$pdf->SetFont('Arial' , 'b' , 10);
// -------------------- Approval-flow footer (auto-inserted) --------------------
require_once('lab_report_footer.php');
lab_render_approval_footer($pdf, $db, '', '');
$pdf->Ln(10);

$pdf->Output();